document.addEventListener("DOMContentLoaded", () => {
  window.scrollTo(0, 0); // При загрузке - прокрутка вверх

  // Плавный скролл по меню
  document.querySelectorAll('nav a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetID = link.getAttribute("href").slice(1);
      const target = document.getElementById(targetID);
      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // Анимация появления секций при скролле
  const faders = document.querySelectorAll(".fade-in");

  const appearOptions = {
    threshold: 0.15,
    rootMargin: "0px 0px -50px 0px",
  };

  const appearOnScroll = new IntersectionObserver((entries, appearOnScroll) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("visible");
      appearOnScroll.unobserve(entry.target);
    });
  }, appearOptions);

  faders.forEach((fader) => {
    appearOnScroll.observe(fader);
  });

  // Модалка с информацией о персонаже
  const modal = document.getElementById("modal");
  const modalImg = document.getElementById("modal-img");
  const modalName = document.getElementById("modal-name");
  const modalDesc = document.getElementById("modal-description");
  const modalClose = document.getElementById("modal-close");

  function openModal(card) {
    modalImg.src = card.dataset.img;
    modalImg.alt = card.dataset.name;
    modalName.textContent = card.dataset.name;
    modalDesc.textContent = card.dataset.description;
    modal.classList.add("show");
    document.body.style.overflow = "hidden"; // отключаем скролл основного сайта
  }

  function closeModal() {
    modal.classList.remove("show");
    document.body.style.overflow = "";
  }

  document.querySelectorAll(".card").forEach((card) => {
    card.addEventListener("click", () => openModal(card));
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openModal(card);
      }
    });
  });

  modalClose.addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  // Закрытие модалки по ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("show")) {
      closeModal();
    }
  });

  // Меню — смена фона при скролле
  const header = document.querySelector(".main-header");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 60) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  });
});
